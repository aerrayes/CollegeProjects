package DBCon;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import Pack.Word;


public class DBCon {
	public static ArrayList<String> getURLsByKeyword(String keyword) {
		String host = "jdbc:mysql://localhost:3306/keywordurl";
		String uName = "root";
		String uPass = "password";
		try {
			Connection con = DriverManager.getConnection(host, uName, uPass);
			ResultSet result = con.createStatement().executeQuery(
					"SELECT url FROM keyword_url where keyword ='" + keyword
							+ "'");
			ArrayList<String> arr = new ArrayList<String>();
			while (result.next()) {
				arr.add(result.getString("url"));
				System.out.println(result.getString("url"));
			}
			con.close();
			return arr;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public static ArrayList<String> getKeywordFromURL(String URL) {
		String host = "jdbc:mysql://localhost:3306/keywordurl";
		String uName = "root";
		String uPass = "password";
		try {
			Connection con = DriverManager.getConnection(host, uName, uPass);
			ResultSet result = con.createStatement().executeQuery(
					"SELECT keyword FROM keyword_url where url ='" + URL + "'");
			ArrayList<String> arr = new ArrayList<String>();
			while (result.next()) {
				arr.add(result.getString("keyword"));
				System.out.println(result.getString("keyword"));
			}
			con.close();
			return arr;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public static boolean insert(String keyword, String url,String priority) {

		String host = "jdbc:mysql://localhost:3306/keywordurl";
		String uName = "root";
		String uPass = "password";
		try {
			Connection con = DriverManager.getConnection(host, uName, uPass);
			java.sql.PreparedStatement pp = con
					.prepareStatement("INSERT INTO keyword_url VALUES (default,?,?,?)");
			pp.setString(1, keyword);
			pp.setString(2, url);
			pp.setString(3, priority);
			int result = pp.executeUpdate();
			con.close();
			if (result == 1)
				return true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static boolean insert(HashMap< String, List<Word>> hm) {

		String host = "jdbc:mysql://localhost:3306/keywordurl";
		String uName = "root";
		String uPass = "password";
		try {
			Connection con = DriverManager.getConnection(host, uName, uPass);
			Iterator it = hm.entrySet().iterator();
			while (it.hasNext()) {
				Entry pairs = (Entry) it.next();
				java.sql.PreparedStatement pp = con
						.prepareStatement("INSERT INTO keyword_url VALUES (default,?,?,?)");
				for(int i =0 ;i<((ArrayList<Word>)pairs.getValue()).size();i++){
					pp.setString(1, (String) pairs.getKey());
					pp.setString(2, (((ArrayList<Word>)pairs.getValue()).get(i)).getUrl());
					pp.setString(3, (((ArrayList<Word>)pairs.getValue()).get(i)).getPriority().name());
					
					int res = pp.executeUpdate();
					if (res == 2)
						System.err.println("Wrong insertion");
				}
			}
			con.close();
			return true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;

	}
}
