package Pack;

public class Word {
	
	Word (Indexer.Priority _priority,String _url){
		priority = _priority;
		url = _url;
	}
	Indexer.Priority priority;
	public Indexer.Priority getPriority() {
		return priority;
	}
	public void setPriority(Indexer.Priority priority) {
		this.priority = priority;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	String url;
}
