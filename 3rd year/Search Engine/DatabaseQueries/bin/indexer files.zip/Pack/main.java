package Pack;
import DBCon.DBCon;


public class main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DBCon.getURLsByKeyword("big");
		DBCon.getKeywordFromURL("www.facebook.com");
		if(DBCon.insert("afasf", "yahfasf.com",Indexer.Priority.TITLE.name())) {
			System.out.println("DONE");
		}
		else System.out.println("nope");
		DBCon.getURLsByKeyword("small");
		
	}

}
